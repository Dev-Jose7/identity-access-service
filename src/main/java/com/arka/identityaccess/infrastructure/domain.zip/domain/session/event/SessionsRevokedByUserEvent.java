package com.arka.identityaccess.domain.session.event;

import com.arka.identityaccess.domain.shared.event.DomainEvent;
import com.arka.identityaccess.domain.shared.exception.DomainInvariantViolationException;
import com.arka.identityaccess.domain.user.valueobject.UserId;
import java.time.Instant;
import java.util.UUID;

public record SessionsRevokedByUserEvent(
        String eventId,
        Instant occurredAt,
        UserId userId,
        UserId revokedBy,
        String reason,
        long revokedSessions) implements DomainEvent {

    public SessionsRevokedByUserEvent {
        if (eventId == null || eventId.isBlank()) {
            eventId = UUID.randomUUID().toString();
        }
        if (occurredAt == null) {
            throw new DomainInvariantViolationException("sessions revoked event requires occurredAt");
        }
        if (userId == null || revokedBy == null) {
            throw new DomainInvariantViolationException("sessions revoked event requires target user and actor");
        }
        if (revokedSessions < 0) {
            throw new DomainInvariantViolationException("revoked sessions count cannot be negative");
        }
        reason = reason == null ? "" : reason.trim();
    }

    public static SessionsRevokedByUserEvent create(
            String userId,
            String revokedBy,
            String reason,
            long revokedSessions,
            Instant occurredAt) {
        return new SessionsRevokedByUserEvent(
                UUID.randomUUID().toString(),
                occurredAt,
                UserId.of(userId),
                UserId.of(revokedBy),
                reason,
                revokedSessions);
    }

    @Override
    public String eventType() {
        return "SessionsRevokedByUser";
    }

    @Override
    public String aggregateId() {
        return userId.value();
    }

    @Override
    public String aggregateType() {
        return "Session";
    }
}
