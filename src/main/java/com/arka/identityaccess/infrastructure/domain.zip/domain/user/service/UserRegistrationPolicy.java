package com.arka.identityaccess.domain.user.service;

import com.arka.identityaccess.domain.shared.exception.OperationNotPermittedException;
import com.arka.identityaccess.domain.role.exception.RoleInvalidException;
import com.arka.identityaccess.domain.role.valueobject.RoleCode;
import com.arka.identityaccess.domain.user.enumtype.RegistrationMode;

public class UserRegistrationPolicy {

    private static final RoleCode DEFAULT_ADMIN_CREATE_ROLE = RoleCode.from("ORG_USER");
    private static final RoleCode FOUNDER_ROLE = RoleCode.from("ORG_OWNER");
    private static final RoleCode FORBIDDEN_ADMIN_CREATE_ROLE = RoleCode.from("ORG_OWNER");
    private static final RoleCode FORBIDDEN_PLATFORM_ROLE = RoleCode.from("ARKA_ADMIN");

    public RegistrationDecision evaluate(
            RegistrationMode registrationMode,
            String requestedRoleCode) {
        if (registrationMode == null) {
            throw new OperationNotPermittedException("Registration mode is required");
        }

        return switch (registrationMode) {
            case ONBOARDING_OWNER -> new RegistrationDecision(FOUNDER_ROLE, false);
            case ADMIN_CREATE -> evaluateAdminCreate(requestedRoleCode);
        };
    }

    private RegistrationDecision evaluateAdminCreate(String requestedRoleCode) {
        RoleCode targetRoleCode = resolveAdminTargetRoleCode(requestedRoleCode);
        return new RegistrationDecision(targetRoleCode, true);
    }

    private RoleCode resolveAdminTargetRoleCode(String requestedRoleCode) {
        if (requestedRoleCode == null || requestedRoleCode.isBlank()) {
            return DEFAULT_ADMIN_CREATE_ROLE;
        }

        RoleCode roleCode = RoleCode.from(requestedRoleCode);
        if (roleCode.equals(FORBIDDEN_ADMIN_CREATE_ROLE) || roleCode.equals(FORBIDDEN_PLATFORM_ROLE)) {
            throw new RoleInvalidException();
        }
        return roleCode;
    }

    public record RegistrationDecision(RoleCode targetRoleCode, boolean requiresActorAssignmentValidation) {}
}
