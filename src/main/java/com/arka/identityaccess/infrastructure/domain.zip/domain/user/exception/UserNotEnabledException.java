package com.arka.identityaccess.domain.user.exception;

import com.arka.identityaccess.domain.shared.exception.DomainException;

public class UserNotEnabledException extends DomainException {

    public UserNotEnabledException() {
        super("usuario_no_habilitado", "User is not enabled to authenticate");
    }
}
