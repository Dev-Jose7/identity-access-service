package com.arka.identityaccess.domain.user.entity;

import com.arka.identityaccess.domain.shared.exception.DomainInvariantViolationException;
import com.arka.identityaccess.domain.session.valueobject.ClientIp;
import com.arka.identityaccess.domain.user.valueobject.UserId;
import java.time.Instant;
import java.util.UUID;

public record AuthenticationAttempt(
        String attemptId,
        UserId userId,
        Instant occurredAt,
        ClientIp clientIp,
        boolean success) {

    public AuthenticationAttempt {
        if (attemptId == null || attemptId.isBlank()) {
            throw new DomainInvariantViolationException("attemptId is required");
        }
        if (userId == null || occurredAt == null || clientIp == null) {
            throw new DomainInvariantViolationException("login attempt is incomplete");
        }
    }

    public static AuthenticationAttempt success(UserId userId, ClientIp clientIp, Instant occurredAt) {
        return new AuthenticationAttempt(UUID.randomUUID().toString(), userId, occurredAt, clientIp, true);
    }

    public static AuthenticationAttempt failed(UserId userId, ClientIp clientIp, Instant occurredAt) {
        return new AuthenticationAttempt(UUID.randomUUID().toString(), userId, occurredAt, clientIp, false);
    }
}
