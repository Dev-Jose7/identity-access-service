package com.arka.identityaccess.domain.user;

import com.arka.identityaccess.domain.shared.event.DomainEvent;
import com.arka.identityaccess.domain.user.exception.UserNotEnabledException;
import com.arka.identityaccess.domain.shared.exception.DomainException;
import com.arka.identityaccess.domain.shared.exception.DomainInvariantViolationException;
import com.arka.identityaccess.domain.user.event.RoleAssignedEvent;
import com.arka.identityaccess.domain.user.event.UserBlockedEvent;
import com.arka.identityaccess.domain.user.event.UserRegisteredEvent;
import com.arka.identityaccess.domain.session.valueobject.ClientIp;
import com.arka.identityaccess.domain.role.valueobject.RoleId;
import com.arka.identityaccess.domain.user.valueobject.AuthenticationDecision;
import com.arka.identityaccess.domain.user.entity.UserCredential;
import com.arka.identityaccess.domain.user.entity.AuthenticationAttempt;
import com.arka.identityaccess.domain.user.enumtype.UserStatus;
import com.arka.identityaccess.domain.user.exception.InvalidCredentialsException;
import com.arka.identityaccess.domain.user.valueobject.EmailAddress;
import com.arka.identityaccess.domain.user.valueobject.UserId;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class UserAggregate {

    private final UserId id;
    private final EmailAddress email;
    private UserStatus status;
    private final UserCredential credential;
    private final List<AuthenticationAttempt> loginAttempts;
    private final Set<RoleId> assignedRoleIds;
    private final List<DomainEvent> domainEvents;

    public UserAggregate(
            UserId id,
            EmailAddress email,
            UserStatus status,
            UserCredential credential,
            List<AuthenticationAttempt> loginAttempts) {
        this(id, email, status, credential, loginAttempts, Set.of());
    }

    public UserAggregate(
            UserId id,
            EmailAddress email,
            UserStatus status,
            UserCredential credential,
            List<AuthenticationAttempt> loginAttempts,
            Set<RoleId> assignedRoleIds) {
        if (id == null || email == null || status == null || credential == null) {
            throw new DomainInvariantViolationException("user aggregate is incomplete");
        }
        this.id = id;
        this.email = email;
        this.status = status;
        this.credential = credential;
        this.loginAttempts = new ArrayList<>(loginAttempts == null ? List.of() : loginAttempts);
        this.assignedRoleIds = new LinkedHashSet<>(assignedRoleIds == null ? Set.of() : assignedRoleIds);
        this.domainEvents = new ArrayList<>();
    }

    public static UserAggregate register(EmailAddress email, String passwordHash, Instant occurredAt) {
        if (occurredAt == null) {
            throw new DomainInvariantViolationException("registration occurrence time is required");
        }
        UserId userId = UserId.newId();
        UserAggregate user = new UserAggregate(
                userId,
                email,
                UserStatus.ACTIVE,
                UserCredential.primaryPassword(userId, email, passwordHash),
                List.of());
        user.recordDomainEvent(UserRegisteredEvent.create(userId, email, occurredAt));
        return user;
    }

    public UserId id() { return id; }
    public EmailAddress email() { return email; }
    public UserStatus status() { return status; }
    public UserCredential credential() { return credential; }
    public List<AuthenticationAttempt> loginAttempts() { return Collections.unmodifiableList(loginAttempts); }
    public Set<RoleId> assignedRoleIds() { return Collections.unmodifiableSet(assignedRoleIds); }
    public List<DomainEvent> domainEvents() { return Collections.unmodifiableList(domainEvents); }

    public AuthenticationAttempt lastAttempt() {
        if (loginAttempts.isEmpty()) {
            return null;
        }
        return loginAttempts.get(loginAttempts.size() - 1);
    }

    public AuthenticationDecision authenticate(boolean passwordMatches, ClientIp clientIp, Instant now) {
        if (clientIp == null || now == null) {
            throw new DomainInvariantViolationException("authentication requires clientIp and occurredAt");
        }
        if (!status.canLogin()) {
            return recordFailedAuthentication(clientIp, now, new UserNotEnabledException());
        }
        if (credential == null || !credential.isActive()) {
            return recordFailedAuthentication(clientIp, now, new InvalidCredentialsException());
        }
        if (!passwordMatches) {
            return recordFailedAuthentication(clientIp, now, new InvalidCredentialsException());
        }
        AuthenticationAttempt successAttempt = AuthenticationAttempt.success(id, clientIp, now);
        loginAttempts.add(successAttempt);
        return AuthenticationDecision.success(successAttempt);
    }

    public boolean isLoginAllowed() {
        return status.canLogin() && credential != null && credential.isActive();
    }

    public boolean assignRole(RoleId roleId, UserId assignedBy, Instant occurredAt) {
        if (roleId == null || assignedBy == null || occurredAt == null) {
            throw new DomainInvariantViolationException("role assignment requires role, actor and occurrence time");
        }
        if (assignedRoleIds.contains(roleId)) {
            return false;
        }
        assignedRoleIds.add(roleId);
        recordDomainEvent(RoleAssignedEvent.create(id, roleId, assignedBy, occurredAt));
        return true;
    }

    public boolean block(UserId blockedBy, String reason, Instant occurredAt) {
        if (blockedBy == null || occurredAt == null) {
            throw new DomainInvariantViolationException("user block requires actor and occurrence time");
        }
        if (status == UserStatus.BLOCKED) {
            return false;
        }
        this.status = UserStatus.BLOCKED;
        recordDomainEvent(UserBlockedEvent.create(id, blockedBy, reason, occurredAt));
        return true;
    }

    private void recordDomainEvent(DomainEvent event) {
        if (event == null) {
            return;
        }
        domainEvents.add(event);
    }

    private AuthenticationDecision recordFailedAuthentication(
            ClientIp clientIp,
            Instant occurredAt,
            DomainException failure) {
        AuthenticationAttempt failedAttempt = AuthenticationAttempt.failed(id, clientIp, occurredAt);
        loginAttempts.add(failedAttempt);
        return AuthenticationDecision.failure(failedAttempt, failure);
    }

    public List<DomainEvent> pullDomainEvents() {
        List<DomainEvent> events = List.copyOf(domainEvents);
        domainEvents.clear();
        return events;
    }

}
