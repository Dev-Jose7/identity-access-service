package com.arka.identityaccess.domain.user.exception;

import com.arka.identityaccess.domain.shared.exception.DomainException;

public class UserAlreadyExistsException extends DomainException {

    public UserAlreadyExistsException() {
        super("usuario_ya_existe", "A user already exists with the provided email");
    }
}
