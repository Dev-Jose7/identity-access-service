package com.arka.identityaccess.domain.role.exception;

import com.arka.identityaccess.domain.shared.exception.DomainException;

public class RoleInvalidException extends DomainException {

    public RoleInvalidException() {
        super("rol_invalido", "Role is invalid for this operation");
    }
}
