package com.arka.identityaccess.domain.user.valueobject;

import com.arka.identityaccess.domain.shared.exception.DomainException;
import com.arka.identityaccess.domain.shared.exception.DomainInvariantViolationException;
import com.arka.identityaccess.domain.user.entity.AuthenticationAttempt;

public record AuthenticationDecision(
        AuthenticationAttempt attempt,
        boolean authenticated,
        DomainException failure) {

    public AuthenticationDecision {
        if (attempt == null) {
            throw new DomainInvariantViolationException("authentication attempt is required");
        }
        if (authenticated && failure != null) {
            throw new DomainInvariantViolationException("successful authentication cannot include failure");
        }
        if (!authenticated && failure == null) {
            throw new DomainInvariantViolationException("failed authentication requires failure");
        }
    }

    public static AuthenticationDecision success(AuthenticationAttempt attempt) {
        return new AuthenticationDecision(attempt, true, null);
    }

    public static AuthenticationDecision failure(AuthenticationAttempt attempt, DomainException failure) {
        return new AuthenticationDecision(attempt, false, failure);
    }
}
