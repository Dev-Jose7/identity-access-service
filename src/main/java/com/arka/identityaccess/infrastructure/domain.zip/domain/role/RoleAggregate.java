package com.arka.identityaccess.domain.role;

import com.arka.identityaccess.domain.role.enumtype.RoleStatus;
import com.arka.identityaccess.domain.role.event.RoleCreatedEvent;
import com.arka.identityaccess.domain.role.event.RoleDisabledEvent;
import com.arka.identityaccess.domain.role.event.RoleUpdatedEvent;
import com.arka.identityaccess.domain.role.valueobject.RoleCode;
import com.arka.identityaccess.domain.role.valueobject.RoleId;
import com.arka.identityaccess.domain.shared.event.DomainEvent;
import com.arka.identityaccess.domain.shared.exception.DomainInvariantViolationException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class RoleAggregate {

    private final RoleId id;
    private final RoleCode code;
    private String displayName;
    private RoleStatus status;
    private final List<DomainEvent> domainEvents;

    private RoleAggregate(RoleId id, RoleCode code, String displayName, RoleStatus status, List<DomainEvent> domainEvents) {
        if (id == null || code == null || displayName == null || displayName.isBlank() || status == null) {
            throw new DomainInvariantViolationException("role aggregate is incomplete");
        }
        this.id = id;
        this.code = code;
        this.displayName = displayName.trim();
        this.status = status;
        this.domainEvents = new ArrayList<>(domainEvents == null ? List.of() : domainEvents);
    }

    public static RoleAggregate create(RoleCode code, String displayName, Instant occurredAt) {
        RoleId id = RoleId.newId();
        return new RoleAggregate(
                id,
                code,
                displayName,
                RoleStatus.ACTIVE,
                List.of(RoleCreatedEvent.create(id, code, occurredAt)));
    }

    public RoleAggregate updateDisplayName(String nextDisplayName, Instant occurredAt) {
        if (nextDisplayName == null || nextDisplayName.isBlank()) {
            throw new DomainInvariantViolationException("role displayName is required");
        }
        if (this.displayName.equals(nextDisplayName.trim())) {
            return this;
        }
        this.displayName = nextDisplayName.trim();
        recordDomainEvent(RoleUpdatedEvent.create(id, occurredAt));
        return this;
    }

    public RoleAggregate disable(Instant occurredAt) {
        if (this.status == RoleStatus.DISABLED) {
            return this;
        }
        this.status = RoleStatus.DISABLED;
        recordDomainEvent(RoleDisabledEvent.create(id, occurredAt));
        return this;
    }

    public RoleId id() {
        return id;
    }

    public RoleCode code() {
        return code;
    }

    public String displayName() {
        return displayName;
    }

    public RoleStatus status() {
        return status;
    }

    public List<DomainEvent> pullDomainEvents() {
        List<DomainEvent> events = List.copyOf(domainEvents);
        domainEvents.clear();
        return events;
    }

    private void recordDomainEvent(DomainEvent event) {
        if (event != null) {
            domainEvents.add(event);
        }
    }
}
