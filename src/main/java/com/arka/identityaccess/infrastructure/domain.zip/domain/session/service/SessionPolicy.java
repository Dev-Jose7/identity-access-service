package com.arka.identityaccess.domain.session.service;

import com.arka.identityaccess.domain.session.exception.SessionAlreadyRevokedException;
import com.arka.identityaccess.domain.session.exception.SessionRefreshNotAllowedException;
import com.arka.identityaccess.domain.user.exception.UserNotEnabledException;
import com.arka.identityaccess.domain.session.SessionAggregate;
import com.arka.identityaccess.domain.session.enumtype.SessionStatus;
import com.arka.identityaccess.domain.user.UserAggregate;
import java.time.Instant;

public class SessionPolicy {

    public void ensureUserCanOpenSession(UserAggregate user) {
        if (user == null || !user.isLoginAllowed()) {
            throw new UserNotEnabledException();
        }
    }

    public void ensureSessionCanRefresh(SessionAggregate session, Instant now) {
        if (session == null || session.status() != SessionStatus.ACTIVE) {
            throw new SessionRefreshNotAllowedException();
        }
        if (!session.timestamps().refreshTokenExpiresAt().isAfter(now)) {
            throw new SessionRefreshNotAllowedException();
        }
    }

    public void ensureSessionCanLogout(SessionAggregate session) {
        if (session == null || session.status() != SessionStatus.ACTIVE) {
            throw new SessionAlreadyRevokedException();
        }
    }
}
