package com.arka.identityaccess.domain.user.event;

import com.arka.identityaccess.domain.shared.event.DomainEvent;
import com.arka.identityaccess.domain.shared.exception.DomainInvariantViolationException;
import com.arka.identityaccess.domain.role.valueobject.RoleId;
import com.arka.identityaccess.domain.user.valueobject.UserId;
import java.time.Instant;
import java.util.UUID;

public record RoleAssignedEvent(
        String eventId,
        Instant occurredAt,
        UserId userId,
        RoleId roleId,
        UserId assignedBy) implements DomainEvent {

    public RoleAssignedEvent {
        if (eventId == null || eventId.isBlank()) {
            eventId = UUID.randomUUID().toString();
        }
        if (occurredAt == null) {
            throw new DomainInvariantViolationException("role assigned event requires occurredAt");
        }
        if (userId == null || roleId == null || assignedBy == null) {
            throw new DomainInvariantViolationException("role assigned event requires user, role and actor");
        }
    }

    public static RoleAssignedEvent create(
            UserId userId,
            RoleId roleId,
            UserId assignedBy,
            Instant occurredAt) {
        return new RoleAssignedEvent(
                UUID.randomUUID().toString(),
                occurredAt,
                userId,
                roleId,
                assignedBy);
    }

    @Override
    public String eventType() {
        return "RoleAssigned";
    }

    @Override
    public String aggregateId() {
        return userId.value();
    }

    @Override
    public String aggregateType() {
        return "User";
    }
}
