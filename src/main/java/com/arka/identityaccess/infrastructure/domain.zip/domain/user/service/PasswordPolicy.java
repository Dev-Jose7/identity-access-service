package com.arka.identityaccess.domain.user.service;

import com.arka.identityaccess.domain.user.exception.InvalidCredentialsException;
import com.arka.identityaccess.domain.user.entity.UserCredential;

public class PasswordPolicy {

    public void ensureCredentialUsable(UserCredential credential) {
        if (credential == null || !credential.isActive()) {
            throw new InvalidCredentialsException();
        }
    }

    public void ensureRawPasswordProvided(String rawPassword) {
        if (rawPassword == null || rawPassword.isBlank()) {
            throw new InvalidCredentialsException();
        }
    }

    public void ensurePasswordMatches(boolean matches) {
        if (!matches) {
            throw new InvalidCredentialsException();
        }
    }
}
