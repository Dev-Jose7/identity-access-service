package com.arka.identityaccess.domain.user.event;

import com.arka.identityaccess.domain.session.valueobject.ClientIp;
import com.arka.identityaccess.domain.shared.event.DomainEvent;
import com.arka.identityaccess.domain.shared.exception.DomainInvariantViolationException;
import com.arka.identityaccess.domain.user.valueobject.EmailAddress;
import com.arka.identityaccess.domain.user.valueobject.UserId;
import java.time.Instant;
import java.util.UUID;

public record AuthenticationFailedEvent(
        String eventId,
        Instant occurredAt,
        UserId userId,
        EmailAddress email,
        ClientIp clientIp)
        implements DomainEvent {

    public AuthenticationFailedEvent {
        if (eventId == null || eventId.isBlank()) {
            eventId = UUID.randomUUID().toString();
        }
        if (occurredAt == null) {
            throw new DomainInvariantViolationException("authentication failed event requires occurredAt");
        }
        if (userId == null || email == null || clientIp == null) {
            throw new DomainInvariantViolationException(
                    "authentication failed event requires user, email and client ip");
        }
    }

    public static AuthenticationFailedEvent create(
            UserId userId,
            EmailAddress email,
            ClientIp clientIp,
            Instant occurredAt) {
        return new AuthenticationFailedEvent(
                UUID.randomUUID().toString(),
                occurredAt,
                userId,
                email,
                clientIp);
    }

    @Override
    public String eventType() {
        return "AuthenticationFailed";
    }

    @Override
    public String aggregateId() {
        return userId.value();
    }

    @Override
    public String aggregateType() {
        return "User";
    }
}
