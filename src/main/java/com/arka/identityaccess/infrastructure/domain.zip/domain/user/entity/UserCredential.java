package com.arka.identityaccess.domain.user.entity;

import com.arka.identityaccess.domain.shared.exception.DomainInvariantViolationException;
import com.arka.identityaccess.domain.user.enumtype.CredentialStatus;
import com.arka.identityaccess.domain.user.valueobject.EmailAddress;
import com.arka.identityaccess.domain.user.valueobject.UserId;
import java.util.UUID;

public record UserCredential(
        String credentialId,
        UserId userId,
        EmailAddress email,
        String passwordHash,
        CredentialStatus status) {

    public UserCredential {
        if (credentialId == null || credentialId.isBlank()) {
            throw new DomainInvariantViolationException("credentialId is required");
        }
        if (userId == null || email == null || passwordHash == null || passwordHash.isBlank() || status == null) {
            throw new DomainInvariantViolationException("credential is incomplete");
        }
    }

    public static UserCredential primaryPassword(UserId userId, EmailAddress email, String passwordHash) {
        return new UserCredential(UUID.randomUUID().toString(), userId, email, passwordHash, CredentialStatus.ACTIVE);
    }

    public boolean isActive() {
        return status.isUsableForLogin();
    }
}
