package com.arka.identityaccess.domain.user.service;

import com.arka.identityaccess.domain.shared.exception.OperationNotPermittedException;

public class AuthenticationPolicy {

    private final int maxFailedAttemptsBeforeBlock;

    public AuthenticationPolicy(int maxFailedAttemptsBeforeBlock) {
        if (maxFailedAttemptsBeforeBlock <= 0) {
            throw new OperationNotPermittedException("max failed attempts must be positive");
        }
        this.maxFailedAttemptsBeforeBlock = maxFailedAttemptsBeforeBlock;
    }

    public int maxFailedAttemptsBeforeBlock() {
        return maxFailedAttemptsBeforeBlock;
    }

    public boolean shouldBlockAfterFailedAttempts(int failedAttempts) {
        return failedAttempts >= maxFailedAttemptsBeforeBlock;
    }
}
