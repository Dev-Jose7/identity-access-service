package com.arka.identityaccess.domain.user.enumtype;

public enum CredentialStatus {
    ACTIVE,
    ROTATED,
    COMPROMISED,
    REVOKED;

    public boolean isUsableForLogin() {
        return this == ACTIVE;
    }
}
