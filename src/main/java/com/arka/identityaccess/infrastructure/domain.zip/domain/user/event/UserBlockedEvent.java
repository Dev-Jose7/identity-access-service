package com.arka.identityaccess.domain.user.event;

import com.arka.identityaccess.domain.shared.event.DomainEvent;
import com.arka.identityaccess.domain.shared.exception.DomainInvariantViolationException;
import com.arka.identityaccess.domain.user.valueobject.UserId;
import java.time.Instant;
import java.util.UUID;

public record UserBlockedEvent(
        String eventId,
        Instant occurredAt,
        UserId userId,
        UserId blockedBy,
        String reason) implements DomainEvent {

    public UserBlockedEvent {
        if (eventId == null || eventId.isBlank()) {
            eventId = UUID.randomUUID().toString();
        }
        if (occurredAt == null) {
            throw new DomainInvariantViolationException("user blocked event requires occurredAt");
        }
        if (userId == null || blockedBy == null) {
            throw new DomainInvariantViolationException("user blocked event requires user and actor");
        }
        reason = reason == null ? "" : reason.trim();
    }

    public static UserBlockedEvent create(
            UserId userId,
            UserId blockedBy,
            String reason,
            Instant occurredAt) {
        return new UserBlockedEvent(
                UUID.randomUUID().toString(),
                occurredAt,
                userId,
                blockedBy,
                reason);
    }

    @Override
    public String eventType() {
        return "UserBlocked";
    }

    @Override
    public String aggregateId() {
        return userId.value();
    }

    @Override
    public String aggregateType() {
        return "User";
    }
}
