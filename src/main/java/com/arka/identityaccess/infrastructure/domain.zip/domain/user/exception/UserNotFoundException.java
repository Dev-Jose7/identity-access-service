package com.arka.identityaccess.domain.user.exception;

import com.arka.identityaccess.domain.shared.exception.DomainException;

public class UserNotFoundException extends DomainException {

    public UserNotFoundException() {
        super("usuario_no_encontrado", "User does not exist");
    }
}
