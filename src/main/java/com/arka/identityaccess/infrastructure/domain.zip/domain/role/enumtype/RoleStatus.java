package com.arka.identityaccess.domain.role.enumtype;

public enum RoleStatus {
    ACTIVE,
    DISABLED;

    public boolean isAssignable() {
        return this == ACTIVE;
    }
}
