package com.arka.identityaccess.domain.session.exception;

import com.arka.identityaccess.domain.shared.exception.DomainException;

public class SessionNotFoundException extends DomainException {

    public SessionNotFoundException() {
        super("sesion_no_encontrada", "Session was not found for the provided credential");
    }
}
