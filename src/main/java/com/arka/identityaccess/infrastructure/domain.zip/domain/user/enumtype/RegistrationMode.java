package com.arka.identityaccess.domain.user.enumtype;

public enum RegistrationMode {
    ONBOARDING_OWNER,
    ADMIN_CREATE
}
