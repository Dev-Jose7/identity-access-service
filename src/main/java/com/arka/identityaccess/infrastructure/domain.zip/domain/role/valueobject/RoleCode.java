package com.arka.identityaccess.domain.role.valueobject;

import com.arka.identityaccess.domain.role.exception.RoleInvalidException;
import java.util.Locale;
import java.util.regex.Pattern;

public record RoleCode(String value) {

    private static final Pattern ROLE_CODE_PATTERN = Pattern.compile("^[A-Z][A-Z0-9_]{1,99}$");

    public RoleCode {
        if (value == null || value.isBlank()) {
            throw new RoleInvalidException();
        }
        value = value.trim().toUpperCase(Locale.ROOT);
        if (!ROLE_CODE_PATTERN.matcher(value).matches()) {
            throw new RoleInvalidException();
        }
    }

    public static RoleCode from(String value) {
        return new RoleCode(value);
    }

    public String name() {
        return value;
    }
}
