package com.arka.identityaccess.domain.user.valueobject;

import com.arka.identityaccess.domain.shared.exception.DomainInvariantViolationException;
import java.util.regex.Pattern;

public record UserId(String value) {

    private static final Pattern USER_ID_PATTERN = Pattern.compile("^[A-Za-z0-9][A-Za-z0-9-]{2,127}$");

    public UserId {
        if (value == null || value.isBlank()) {
            throw new DomainInvariantViolationException("userId is required");
        }
        value = value.trim();
        if (!USER_ID_PATTERN.matcher(value).matches()) {
            throw new DomainInvariantViolationException("userId format is invalid");
        }
    }

    public static UserId newId() {
        return new UserId(java.util.UUID.randomUUID().toString());
    }

    public static UserId of(String value) {
        return new UserId(value);
    }
}
