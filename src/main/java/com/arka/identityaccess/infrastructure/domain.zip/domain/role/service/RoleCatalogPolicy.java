package com.arka.identityaccess.domain.role.service;

import com.arka.identityaccess.domain.role.RoleAggregate;
import com.arka.identityaccess.domain.role.exception.RoleInvalidException;

public class RoleCatalogPolicy {

    public void ensureAssignable(RoleAggregate role) {
        if (role == null || !role.status().isAssignable()) {
            throw new RoleInvalidException();
        }
    }
}
